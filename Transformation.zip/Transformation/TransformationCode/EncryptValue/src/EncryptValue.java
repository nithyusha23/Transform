import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.*;


public class EncryptValue {
	private static final String ALGO = "AES";
	
	private static String Encrypt(String Data, String passkey) throws Exception  {
		Key key = new SecretKeySpec(passkey.getBytes(), ALGO);
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes());
        String encryptedValue = new BASE64Encoder().encode(encVal);
        return encryptedValue;
	}
	
	public static void main(String[] args) throws Exception {
		try {
			String key = EncryptValue.Encrypt(args[0], args[1]);
			System.out.println(key);
			System.out.println("Encryption successful");
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Error in generating the Encrypted value: "+ex);
		}
	}
}
