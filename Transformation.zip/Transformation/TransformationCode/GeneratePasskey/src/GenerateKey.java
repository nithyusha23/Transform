import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class GenerateKey {
	private static String generateKey() throws NoSuchAlgorithmException  {
		SecureRandom random = SecureRandom.getInstanceStrong();
        byte[] values = new byte[8]; // 8 bit
        random.nextBytes(values);

        StringBuilder sb = new StringBuilder();
        for (byte b : values) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
	}
	
	public static void main(String[] args) throws Exception {
		
		try {
			String key = GenerateKey.generateKey();
			System.out.println(key);
		} catch (Exception ex) {
			System.out.println("Error in generating the key");
		}
		
	}
}