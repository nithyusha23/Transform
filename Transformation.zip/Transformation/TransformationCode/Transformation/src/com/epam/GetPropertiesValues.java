package com.epam;

/*
 * Author: ravi_gupta@epam.com
 * */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
public class GetPropertiesValues {

	InputStream inputStream;
	Hashtable<String, String> keyValues;
	public Hashtable<String, String> getPropValues(String fileAddress, String isPassKeyAvailable) throws IOException {
 
		try {
			Properties prop = new Properties();
			String propFileName = fileAddress;
 
			inputStream = new FileInputStream(fileAddress);
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
			// get the property value and print it out
			Enumeration keys = prop.propertyNames();
			keyValues = new Hashtable<String, String>();
			List<String> listOfEncryptedKeys = Arrays.asList(prop.getProperty("enckeys").split(","));
			//System.out.println(listOfEncryptedKeys);
			for (; keys.hasMoreElements();) {
				String nextKey = keys.nextElement().toString();
				//System.out.println(nextKey);
				
				//System.out.println(listOfEncryptedKeys.contains(nextKey));
				String DecryptedValue = null;
				
				if (isPassKeyAvailable != "false" && listOfEncryptedKeys.contains(nextKey)) {
					DecryptedValue = EncryptionDecryption.decrypt(prop.getProperty(nextKey), isPassKeyAvailable);
				} else {
					DecryptedValue = prop.getProperty(nextKey);
				}
				//System.out.println(DecryptedValue);
				keyValues.put(nextKey, DecryptedValue);
			}
			System.out.println("Got all the values");
		} catch (Exception e) {
			System.out.println("Error in decrypting the values!!!");
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return keyValues;
	}
}
