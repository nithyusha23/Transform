package com.epam;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.LineIterator;
 
public class PropertiesTest {
 
	public static void main(String[] args) throws ConfigurationException {
		try {
			File devFile = new File(args[0]);
			File destinationDevopsFile = new File(args[1]);
			//FileUtils.touch(destinationDevopsFile);
			FileUtils.copyFile(devFile, destinationDevopsFile);			
			PropertiesConfiguration config = new PropertiesConfiguration(args[1]);
			
			GetPropertiesValues getpropertiesvalues = new GetPropertiesValues();
			String isPassKeyAvailable = "false";
			if (args.length > 3) {
				isPassKeyAvailable = args[3];
			}
			Hashtable<String, String> keyValues = getpropertiesvalues.getPropValues(args[2], isPassKeyAvailable);	
			Set<String> keys = keyValues.keySet();			
	        for(String key: keys) { 
	            if (!key.equals("enckeys")) {	           
	            	config.setProperty(key, keyValues.get(key));	            	
	            }	            
	        }
	        
	        InputStream inputStream = null;
	        if (args.length > 4) {
	        	Properties prop = new Properties();
	        	inputStream = new FileInputStream(args[4]);
				if (inputStream != null) {
					prop.load(inputStream);
				} else {
					throw new FileNotFoundException("property file '" + args[4] + "' not found in the classpath");
				}
				Enumeration optionalFilekeys = prop.propertyNames();
				for (; optionalFilekeys.hasMoreElements();) {
					String nextKey = optionalFilekeys.nextElement().toString();
					config.clearProperty(nextKey);
				}
			}
	        config.save();
	        if (args.length > 4) {
	        	InputStream optionalFileinputStream = new FileInputStream(args[4]);	    
		        FileUtils.writeByteArrayToFile(destinationDevopsFile, IOUtils.toByteArray(optionalFileinputStream), true);
	        }	       	        
	        System.out.println("Updating the values");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Config Property Successfully Updated..");
	}
}