$ErrorActionPreference="Stop"

Add-Type -assembly "system.io.compression.filesystem"

$PorzioSource = "$($env:workspace)\bin\Debug"
$Porziodestination = "$($env:workspace)\Artifacts\QA\Porzio.zip"
     
[io.compression.zipfile]::CreateFromDirectory($PorzioSource, $Porziodestination)

exit 0
