$ErrorActionPreference="Stop"

Add-Type -assembly "system.io.compression.filesystem"
$Webrole = "$($env:workspace)\Porzio.Its.WebRole"
$InRule = "$($env:workspace)\InRuleCatalogDeployment"
$Azuresource = "$($env:workspace)\tempfiles\cspack"
$WebRoledestination = "$($env:workspace)\Artifacts\QA\webrole.zip"
$InRuledestination = "$($env:workspace)\Artifacts\QA\InRule.zip"
$Azuredestination = "$($env:workspace)\Artifacts\QA\Azure.zip"
$cspkg = "$($env:workspace)\Porzio.Its.AzureService\ServiceDefinition.cspkg"
$cscfg = "$($env:workspace)\Porzio.Its.AzureService\ServiceConfiguration.Cloud.cscfg"
$csdef = "$($env:workspace)\Porzio.Its.AzureService\ServiceDefinition.csdef"
$Azurepackage = "$($env:workspace)\tempfiles\cspack\Porzio.Its.AzureService"
 if((Test-path $Azuresource))
 {  
     Remove-item -path $Azuresource -recurse
 }
  mkdir $Azurepackage
  Copy-Item $cspkg $Azurepackage -recurse
  Copy-Item $cscfg $Azurepackage -recurse 
  Copy-Item $csdef $Azurepackage -recurse 
  Copy-Item $Webrole $Azuresource -recurse
  Copy-Item $InRule $Azuresource -recurse
     

# [io.compression.zipfile]::CreateFromDirectory($Webrole, $WebRoledestination)
# [io.compression.zipfile]::CreateFromDirectory($InRule, $InRuledestination)
[io.compression.zipfile]::CreateFromDirectory($Azuresource, $Azuredestination)

exit 0