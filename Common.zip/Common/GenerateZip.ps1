$ErrorActionPreference="Stop"

$Azuresource = "$($env:workspace)\$($env:SVN_FOLDER_NAME)\Porzio.Its.AzureService\bin\CI\app.publish"

$Azuredestination = "$($env:workspace)\Artifacts\$($env:Environment)\appPublish.zip"

 If(Test-path $Azuredestination) {Remove-item $Azuredestination}

Add-Type -assembly "system.io.compression.filesystem"


[io.compression.zipfile]::CreateFromDirectory($Azuresource, $Azuredestination) 

