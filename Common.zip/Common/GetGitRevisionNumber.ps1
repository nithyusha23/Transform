$gitlogfile = Get-Content -Path $env:workspace\.git\refs\remotes\origin\$env:GIT_BRANCH | Select-Object -First 1
$localrevision = $gitlogfile.Substring(0,7)
$localrevisionnumber ='localrevisionnumber = ' + $localrevision
$Environment ='Environment = ' + $env:Environment
$GIT_BRANCH ='GIT_BRANCH = ' + $env:GIT_BRANCH
$VersionNumber ='VersionNumber = ' + $env:Major_Revision + '.' + $env:Minor_Revision + '.' + $localrevision + '.' + $env:Build_Id
$ErrorActionPreference="Stop"

$localrevisionnumber | Set-Content $env:workspace\$env:Deployment_Details_File.Properties
$Environment | Add-Content $env:workspace\$env:Deployment_Details_File.Properties
$GIT_BRANCH | Add-Content $env:workspace\$env:Deployment_Details_File.Properties
$VersionNumber | Add-Content $env:workspace\$env:Deployment_Details_File.Properties
