Add-Type -AssemblyName System.IO.Compression.FileSystem
$AzureSource = "$($env:workspace)\Artifacts\QA\Azure.zip"
$AzureDestination = "$($env:workspace)\Artifacts\QA\Azure" 
if(!(Test-Path $AzureSource))
{
echo "***************Downloaded Artifacts not present************************"
exit 0
}

 [System.IO.Compression.ZipFile]::ExtractToDirectory($AzureSource,$AzureDestination)
 
 exit 0